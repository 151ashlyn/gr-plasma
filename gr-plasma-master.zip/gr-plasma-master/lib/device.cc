/* -*- c++ -*- */
/*
 * Copyright 2022 gr-plasma author.
 *
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#include <gnuradio/io_signature.h>
#include <gnuradio/plasma/device.h>

namespace gr {
namespace plasma {
} /* namespace plasma */
} /* namespace gr */
